package shop.mtcoding.orange2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Orange2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
