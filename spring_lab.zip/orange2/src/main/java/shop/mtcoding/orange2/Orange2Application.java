package shop.mtcoding.orange2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Orange2Application {

	public static void main(String[] args) {
		SpringApplication.run(Orange2Application.class, args);
	}

}
